package com.example.team_sallab.pref;

public interface loginFormActivity {
    public void preformLogin(String name , String password);
}
