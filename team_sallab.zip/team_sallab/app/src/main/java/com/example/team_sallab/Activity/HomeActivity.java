package com.example.team_sallab.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.team_sallab.R;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}
