package com.example.team_sallab.Network;

import android.graphics.Bitmap;

public interface BackgroundImageTaskInterface
{
    void processFinished(Bitmap response);
}
