package com.example.team_sallab.Network;

public interface BackgroundTaskInterface
{
    void processFinished(String response);
}
